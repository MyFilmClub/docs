package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

@Configuration
public class CorsConfig {

    @Bean
    public CorsFilter corsFilter() {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowCredentials(true); // 如果你的请求需要携带Cookie或认证信息，需要设置为true
        config.addAllowedOrigin("http://localhost:8080"); // 允许特定的前端源
        config.addAllowedHeader("*"); // 允许所有的HTTP头部
        config.addAllowedMethod("*"); // 允许所有的HTTP方法（GET, POST, PUT, DELETE等）

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config); // 对所有路径应用CORS配置

        return new CorsFilter(source);
    }
}
