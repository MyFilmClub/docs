package com.example.demo.Mapper;


import com.example.demo.pojo.*;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface UserMapper {
    User findByUsernameAndPassword(@Param("username") String username, @Param("password") String password);

    int insertUser(User user);
    int getMaxUid();
    int  updateUserInfo(User updateUser);
    int addRelation(Relation relation);

    List<Post> findPost(Integer uid);
    List<Post> findCollectedPost(Integer uid);
    List<Post> findHistoryPost(Integer uid);

    int deleteHistory(Integer uid);
    int getHistoryCount(Integer uid);

    int findUserByName(String username);

    String getUserTags(Integer uid);

    List<Film> recommendationFilm(@Param("tagList")List<String> tagList);

    int addCollectNum(Integer pid);
    Integer findCollectRelation(Relation relation);

    List<String> getTags(Integer uid);

    Integer updateTags(@Param("uid") Integer uid,@Param("newTags") String newTags);
}
