package com.example.demo.Controller;

import com.example.demo.Service.PostService;
import com.example.demo.Service.UserService;
import com.example.demo.pojo.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
public class UserController {

    @Autowired
    private UserService userService;
    @Autowired
    private PostService postService;

    // 用户登录验证
    @PostMapping("/user/login")
    public ResponseEntity<Object> loginUser(@RequestParam String username,@RequestParam String password) {

        User user = userService.login(username, password);

        if (user != null) {
            // 登录成功，返回成功的 code
            return ResponseEntity.ok(Collections.singletonMap("code", 81));
        } else {
            // 用户名或密码错误，返回相应的 code
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Collections.singletonMap("code", 26));
        }
    }

    // 用户注册 (用户名不能重复）
    @PostMapping("/user/signup")
    public ResponseEntity<?> signUpUser(@RequestBody UserRequest userRequest) {

        boolean reulst = userService.registerUser(userRequest);
        if (reulst){
            return ResponseEntity.ok().body("{\"code\": 200, \"message\": \"Sign up successful\"}");
        }else{
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("{\"code\": 500, \"message\": \"username exist\"}");
        }
    }

    // 修改用户信息
    @PutMapping("/user")
    public ResponseEntity<?> UpdateUserInfo(@RequestBody User updateUser) {
         boolean result = userService.updateUser(updateUser);
         if (result){
             return ResponseEntity.ok().body("{\"code\": 200, \"message\": \"Update successful\"}");
         }else{
             return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("{\"code\": 500, \"message\": \"Update failed\"}");
         }

    }

    //收藏帖子(添加关系+收藏数加1)
    @PostMapping("/collect")
    public ResponseEntity<?> collectPost(@RequestBody Collect collect) {
        Relation relation = new Relation(collect.getUid(),collect.getPid(),"c");
        boolean reulst = userService.collectPost(relation);
        if (reulst){
            return ResponseEntity.ok().body("{\"code\": 200, \"message\": \"Collect successful\"}");
        }else{
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("{\"code\": 500, \"message\": \"Collect failed\"}");
        }
    }

    //查询发布过的帖子
    @GetMapping("/findPost/{uid}")
    public ResponseEntity<?> findPost(@PathVariable Integer uid){
        List<Post> posts = userService.findPost(uid);
        Map<String, Object> responseData = new HashMap<>();
        responseData.put("code", 0);
        responseData.put("data",posts);
        return ResponseEntity.ok(responseData);
    }

    //查询收藏过的帖子
    @GetMapping("/findCollectedPost/{uid}")
    public ResponseEntity<?> findCollectedPost(@PathVariable Integer uid){
        List<Post> posts = userService.findCollectedPost(uid);
        Map<String, Object> responseData = new HashMap<>();
        responseData.put("code", 0);
        responseData.put("data",posts);
        return ResponseEntity.ok(responseData);
    }

    //查询浏览历史
    @GetMapping("/findHistory/{uid}")
    public ResponseEntity<?> findHistory(@PathVariable Integer uid){
        List<Post> posts = userService.findHistory(uid);
        Map<String, Object> responseData = new HashMap<>();
        responseData.put("code", 0);
        responseData.put("data",posts);
        return ResponseEntity.ok(responseData);
    }
    //删除浏览历史
    @GetMapping("/deleteHistory/{uid}")
    public ResponseEntity<?> deleteHistory(@PathVariable Integer uid){
        boolean result = userService.deleteHistory(uid);
        if (result){
            return ResponseEntity.ok().body("{\"code\": 200, \"message\": \"Delete history successful\"}");
        }else{
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("{\"code\": 500, \"message\": \"Delete history failed\"}");
        }
    }

    @GetMapping("/recommendation/{uid}")
    public ResponseEntity<?> supportFilm(@PathVariable Integer uid){
        //获取用户推荐电影列表
        List<Film> result = userService.recommendationFilm(uid);
        if (!result.isEmpty()){
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("code", 0);
            responseData.put("data",result);
            return ResponseEntity.ok(responseData);
        }else{
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("{\"code\": 500, \"message\": \"there is no film\"}");
        }
    }

    @GetMapping("/tags/{uid}")
    public ResponseEntity<?> getTags(@PathVariable Integer uid){

        List<String> tags = userService.getTags(uid);
        if (!tags.isEmpty()){
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("code", 0);
            responseData.put("data",tags);
            return ResponseEntity.ok(responseData);
        }else{
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("{\"code\": 500, \"message\": \"there is no film\"}");
        }
    }

    // 用户标签更新
    @PostMapping("/updateTags")
    public ResponseEntity<Object> loginUser(@RequestParam Integer uid,@RequestParam String newTags) {
//        System.out.println("uid"+uid+"tags"+newTags);
        Integer result = userService.updateTags(uid,newTags);

        if (result != 0) {
            return ResponseEntity.ok(Collections.singletonMap("code", 81));
        } else {

            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Collections.singletonMap("code", 26));
        }
    }
}
