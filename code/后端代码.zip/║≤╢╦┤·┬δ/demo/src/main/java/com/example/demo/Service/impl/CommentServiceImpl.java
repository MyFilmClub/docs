package com.example.demo.Service.impl;

import com.example.demo.Mapper.CommentMapper;
import com.example.demo.Service.CommentService;
import com.example.demo.pojo.Comment;
import com.example.demo.pojo.CommentShow;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CommentServiceImpl implements CommentService {
    @Autowired
    private CommentMapper commentMapper;

    @Override
    //根据pid查询所有帖子评论
    public List<CommentShow> getCommentsByPid(Integer pid) {
        return commentMapper.getCommentsByPid(pid);
    }
    @Override
    public boolean deleteCommentByCid(Integer cid) {
        int result = commentMapper.deleteCommentById(cid);
        if (result>0){
            return true;
        }
        return false;
    }

    @Override
    public boolean addCommentlike(Integer cid) {
        int result = commentMapper.like(cid);
        if(result>0){
            return true;
        }
        return false;
    }

    @Override
    public boolean addCommentdislike(Integer cid) {
        int result = commentMapper.dislike(cid);
        if(result>0){
            return true;
        }
        return false;
    }

    @Override
    public boolean createComment(Comment comment) {
        int result = commentMapper.createComment(comment);
        if(result>0){
            return true;
        }
        return false;
    }

    @Override
    public int count() {
        return commentMapper.countComment();
    }

    @Override
    public boolean cancelCommentdislike(Integer cid) {
        int result = commentMapper.canceldislike(cid);
        if (result>0){
            return true;
        }
        return false;
    }

}
