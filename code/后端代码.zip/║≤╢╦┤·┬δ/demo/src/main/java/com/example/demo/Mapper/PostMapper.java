package com.example.demo.Mapper;


import com.example.demo.pojo.Post;
import com.example.demo.pojo.PostShow;
import com.example.demo.pojo.Relation;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface PostMapper {
    int insertPost(Post post);
    int updatePost(Post post);

    int collect(Integer pid);
    int like(Integer pid);
    int getArticlePageCount();

    int addHistoryPost(Relation relation);
    List<PostShow> getPostsByFid(Integer fid);
    PostShow getPostByPid(Integer pid);
    Post findPostById(Integer pid);

    int deletePostById1(Integer pid);
    int deletePostById2(Integer pid);
    int deletePostById3(Integer pid);
    int findRelation(Relation relation);
    int addLikePost(Relation relation);
    int deleteLikeRelation(Relation relation);
}
