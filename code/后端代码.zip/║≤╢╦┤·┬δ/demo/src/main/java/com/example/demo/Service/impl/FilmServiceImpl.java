package com.example.demo.Service.impl;

import com.example.demo.Mapper.FilmMapper;
import com.example.demo.Service.FilmService;
import com.example.demo.pojo.Film;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FilmServiceImpl implements FilmService {

    @Autowired
    private FilmMapper filmMapper;

    @Override
    //根据fid查询电影
    public Film getFilmByFid(Integer fid) {
        return filmMapper.getFilmByFid(fid);
    }

    @Override
    //根据搜索信息查找电影
    public List<Film> getFilmsByName(String fname) {
        return filmMapper.findFilmsByName(fname);
    }

    //根据电影标签查找电影
    @Override
    public List<Film> getFilmByTags(List<String> movieTypes) {
        return filmMapper.getFilmsByTags(movieTypes);
    }

    @Override
    public List<Film> getFilm() {
        return filmMapper.getFilm();
    }


}
