package com.example.demo.Service;

import com.example.demo.pojo.*;
import org.springframework.stereotype.Service;

import java.util.List;


public interface UserService {
    User login(String username, String password);
    boolean registerUser(UserRequest user);
    boolean updateUser(User updateUser);
    boolean collectPost(Relation relation);

    List<Post> findPost(Integer uid);
    List<Post> findCollectedPost(Integer uid);
    List<Post> findHistory(Integer uid);
    boolean deleteHistory(Integer uid);
    List<Film> recommendationFilm(Integer uid);

    List<String> getTags(Integer uid);

    Integer updateTags(Integer uid,String newTags);
}
