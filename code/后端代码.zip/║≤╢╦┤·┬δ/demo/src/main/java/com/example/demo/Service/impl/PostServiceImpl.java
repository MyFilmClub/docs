package com.example.demo.Service.impl;

import com.example.demo.Mapper.PostMapper;
import com.example.demo.Mapper.UserMapper;
import com.example.demo.Service.PostService;
import com.example.demo.pojo.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PostServiceImpl implements PostService {
    @Autowired
    private PostMapper postMapper;
    @Autowired
    private UserMapper userMapper;
    @Override
    public Post createPost(PostRequest postRequest) {
        Integer pid = postMapper.getArticlePageCount()+1;
        Post post = new Post(pid,postRequest.getUid(),postRequest.getPcontent(),
                postRequest.getPicurl(),postRequest.getSeenum(),postRequest.getLikenum(),postRequest.getCollectnum(),postRequest.getPtitle(),postRequest.getValue(),postRequest.getFid());
        int result = postMapper.insertPost(post);
        if (result>0){
            Relation relation = new Relation(post.getUid(),post.getPid(),"r");
            userMapper.addRelation(relation);
            return post;
        }else{
            return null;
        }
    }

    @Override
    //根据fid查询所有电影帖子
    public List<PostShow> getPostsByFid(Integer fid) {
        return postMapper.getPostsByFid(fid);
    }
    @Override
    //根据pid查询帖子
    public PostShow getPostByPid(Integer pid) {
        return postMapper.getPostByPid(pid);
    }

    //修改帖子
    @Override
    public boolean updatePost(Post post) {
        int result = postMapper.updatePost(post);
        if (result>0){
            return true;
        }
        else{
            return false;
        }
    }

    //帖子点赞
    @Override
    public boolean addPostlike(Relation relation) {
        int count = postMapper.findRelation(relation);
        if (count>0){
            //该用户已经对该帖子点过赞了
            return true;
        }
        //该用户还没对该帖子点过赞
        int result_1 = postMapper.addLikePost(relation);
        int result = postMapper.like(relation.getPid());
        if (result_1>0 && result>0){
            return true;
        }
        return false;
    }

    //添加浏览历史
    @Override
    public boolean addHistoryPost(Relation relation_history) {
        //如果之前已经浏览过了就不添加了
        int count = postMapper.findRelation(relation_history);
        if (count>0){
            return true;
        }
        int result = postMapper.addHistoryPost(relation_history);
        if (result>0){
            return true;
        }else{
            return false;
        }
    }

    //根据Id查找帖子
    @Override
    public Post findPostById(Integer pid) {
        return postMapper.findPostById(pid);
    }

    //删除帖子
    @Override
    public boolean deletePostByPid(Integer pid) {
        int result3 = postMapper.deletePostById3(pid);
        int result1 = postMapper.deletePostById2(pid);
        int result2 = postMapper.deletePostById1(pid);
        if (result1>0 && result2>0 && result3>0){
            return true;
        }
        return false;
    }
    //取消帖子点赞
    @Override
    public boolean cancelPostLike(Relation relation) {
        int count = postMapper.findRelation(relation);
        if(count>0){
            //存在like关系,删除like关系
            int result = postMapper.deleteLikeRelation(relation);
            return result > 0;
        }
        return false;
    }

}
