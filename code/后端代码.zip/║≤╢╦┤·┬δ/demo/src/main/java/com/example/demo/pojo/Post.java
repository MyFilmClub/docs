package com.example.demo.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Post {
    private Integer pid;
    private Integer uid;
    private String pcontent;
    private String picurl;
    private Integer seenum;
    private Integer likenum;
    private Integer collectnum;
    private String ptitle;
    private Integer value;
    private Integer fid;
}
