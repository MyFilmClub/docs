package com.example.demo.Service;

import com.example.demo.pojo.Film;

import java.util.List;

public interface FilmService {
    Film getFilmByFid(Integer fid);
    List<Film> getFilmsByName(String fname);

    List<Film> getFilmByTags(List<String> movieTypes);

    List<Film> getFilm();
}
