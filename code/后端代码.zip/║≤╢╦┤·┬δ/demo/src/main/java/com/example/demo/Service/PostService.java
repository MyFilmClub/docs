package com.example.demo.Service;


import com.example.demo.pojo.*;

import java.util.List;

public interface PostService {
    Post createPost(PostRequest postRequest);

    boolean updatePost(Post post);

    boolean addPostlike(Relation relation);

    boolean addHistoryPost(Relation relation_history);

    Post findPostById(Integer pid);
    List<PostShow> getPostsByFid(Integer fid);

    PostShow getPostByPid(Integer pid);
    boolean deletePostByPid(Integer pid);
    boolean cancelPostLike(Relation relation);

}
