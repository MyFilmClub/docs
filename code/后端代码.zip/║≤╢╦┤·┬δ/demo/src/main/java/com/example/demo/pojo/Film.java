package com.example.demo.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Film {
   private String fid;
   private String fname;
   private String area;
   private LocalDateTime date;
   private String picurl;
   private Integer rank;
   private String info;
   private String  type;
   private String language;
   private int flength;
   private String director;
   private String scriptwriter;
   private String actor;

}
