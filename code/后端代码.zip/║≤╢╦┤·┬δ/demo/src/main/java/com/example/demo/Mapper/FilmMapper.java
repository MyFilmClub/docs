package com.example.demo.Mapper;

import com.example.demo.pojo.Film;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface FilmMapper {
    //根据fid查询电影

    Film getFilmByFid(@Param("fid") Integer fid);

    //搜索电影名称搜索电影
    List<Film> findFilmsByName(@Param("fname") String fname);

    List<Film> getFilmsByTags(@Param("movieTypes") List<String> movieTypes);
    List<Film> findAllFilms();

    List<Film> getFilm();
}
