package com.example.demo.Controller;

import com.example.demo.Service.FilmService;
import com.example.demo.pojo.Film;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
public class FilmController {
    @Autowired
    private FilmService filmService;

    //查询电影 fid （integer）
    @GetMapping("/film/{fid}")
    public ResponseEntity<Object> getFilmByFid(@PathVariable Integer fid) {
        System.out.println(fid);
        Film film = filmService.getFilmByFid(fid);
        if (film != null) {
            // 构建成功时返回的 JSON 数据
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("code", 0);
            responseData.put("data", film);
            return ResponseEntity.ok(responseData);
        } else {
            // 返回 400 Response，空的 JSON 对象
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Collections.emptyMap());
        }
    }

    @GetMapping("/filmall")
    public ResponseEntity<Object> getFilm() {
        List<Film> film = filmService.getFilm();
        if (film != null) {
            // 构建成功时返回的 JSON 数据
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("code", 0);
            responseData.put("data", film);
            return ResponseEntity.ok(responseData);
        } else {
            // 返回 400 Response，空的 JSON 对象
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Collections.emptyMap());
        }
    }

    //根据电影名查询电影
    @PostMapping("/film/ser/{fname}")
    public ResponseEntity<?> searchFilmByName(@PathVariable String fname) {

        List<Film> films = filmService.getFilmsByName(fname);
        if (films != null) {
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("code", 0);
            responseData.put("data",films);
            return ResponseEntity.ok(responseData);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("{}");
        }
    }

    //根据标签查询电影
    @PostMapping("/film")
    public ResponseEntity<Object> getFilmByTags(@RequestBody List<String> movieTypes) {
        List<Film> films = filmService.getFilmByTags(movieTypes);
        if (films != null) {
            log.info("success");
            // 构建成功时返回的 JSON 数据
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("code", 0);
            responseData.put("data", films);
            return ResponseEntity.ok(responseData);
        } else {
            // 返回 400 Response，空的 JSON 对象
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Collections.emptyMap());
        }
    }
}
