package com.example.demo.Controller;

import com.example.demo.Service.CommentService;
import com.example.demo.pojo.Comment;
import com.example.demo.pojo.CommentRequest;
import com.example.demo.pojo.CommentShow;
import com.example.demo.pojo.Post;
import org.apache.ibatis.annotations.Delete;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class CommentController {
    @Autowired
    private CommentService commentService;

    //根据帖子pid查询所有评论 cid （integer）
    @GetMapping("/post_comments/{pid}")
    public ResponseEntity<Object> getCommentsByPid(@PathVariable Integer pid) {
        System.out.println(pid);
        List<CommentShow> post_comments = commentService.getCommentsByPid(pid);
        if (post_comments != null) {
            // 构建成功时返回的 JSON 数据
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("code", 0);
            responseData.put("data", post_comments);
            return ResponseEntity.ok(responseData);
        } else {
            // 返回 400 Response，空的 JSON 对象
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Collections.emptyMap());
        }
    }

    //删除评论
    @DeleteMapping("/comment/{cid}")
    public ResponseEntity<Object> deleteComment(@PathVariable("cid") Integer cid) {
        boolean result = commentService.deleteCommentByCid(cid);
        if (result){
            return ResponseEntity.status(HttpStatus.OK).body(Map.of("code", 31));
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("code", 0));
    }

    //评论点赞
    @PostMapping(path = "/commentlike/{cid}")
    public ResponseEntity<Object> addCommentlike(@PathVariable Integer cid) {
        boolean result = commentService.addCommentlike(cid);
        if(result){
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("code", 0);
            return ResponseEntity.ok(responseData);
        }
        else{
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("code", 1);
            return ResponseEntity.ok(responseData);
        }
    }

    //评论点踩
    @PostMapping(path = "/dislike/{cid}")
    public ResponseEntity<Object> addCommentdislike(@PathVariable Integer cid) {
        boolean result = commentService.addCommentdislike(cid);
        if(result){
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("code", 0);
            return ResponseEntity.ok(responseData);
        }
        else{
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("code", 1);
            return ResponseEntity.ok(responseData);
        }
    }
    //评论点踩
    @PostMapping(path = "/canceldislike/{cid}")
    public ResponseEntity<Object> cancelCommentdislike(@PathVariable Integer cid) {
        boolean result = commentService.cancelCommentdislike(cid);
        if(result){
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("code", 0);
            return ResponseEntity.ok(responseData);
        }
        else{
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("code", 1);
            return ResponseEntity.ok(responseData);
        }
    }

    //发布评论
    @PostMapping(path = "/comment",consumes = MediaType.APPLICATION_XML_VALUE)
    public ResponseEntity<Object> createPostFromXml(@RequestBody CommentRequest commentRequest) {
        Integer new_cid = commentService.count()+1;
        Comment comment = new Comment(new_cid,commentRequest.getCcontent(),commentRequest.getLikenum(),commentRequest.getDislikenum()
        ,commentRequest.getUid(),commentRequest.getPid());
        boolean result = commentService.createComment(comment);
        if(result){
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("code", 0);
            responseData.put("data",comment);
            return ResponseEntity.ok(responseData);
        }
        else{
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("code", 1);
            return ResponseEntity.ok(responseData);
        }
    }
}
