package com.example.demo.Service.impl;

import com.example.demo.Mapper.FilmMapper;
import com.example.demo.Mapper.PostMapper;
import com.example.demo.Mapper.UserMapper;
import com.example.demo.Service.UserService;
import com.example.demo.pojo.*;
import org.apache.ibatis.annotations.Select;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;
    @Autowired
    private PostMapper postMapper;

    @Autowired
    private FilmMapper filmMapper;
    @Override
    public User login(String username, String password) {
        return userMapper.findByUsernameAndPassword(username,password);
    }

    public boolean registerUser(UserRequest user){
        int if_exist = userMapper.findUserByName(user.getUsername());
        if (if_exist>0){
            return false;
        }
        else {
            int num = userMapper.getMaxUid();
            User new_user = new User(num + 1, user.getUsername(), user.getPassword(), null, null);
            int result = userMapper.insertUser(new_user);
            if (result > 0) {
                return true;
            } else {
                return false;
            }
        }
    }

    @Override
    public boolean updateUser(User updateUser) {
        //如果修改用户名，判断是否重名
        String new_name = updateUser.getUsername();
        if (userMapper.findUserByName(new_name)>0){
            return false;
        }
        int  result = userMapper.updateUserInfo(updateUser);
        if(result>0){
            return true;
        }else{
            return false;
        }
    }

    @Override
    public boolean collectPost(Relation relation) {
//        //如果收藏过了
//        int count =userMapper.findCollectRelation(relation);
//        if (count>0){
//            return true;
//        }
        //未收藏过
        userMapper.addCollectNum(relation.getPid());
        int result = userMapper.addRelation(relation);
        if (result>0){
            int row = postMapper.collect(relation.getPid());
            if (row>0){
                return true;
            }
        }
        return false;
    }

    @Override
    public List<String> getTags(Integer uid) {
        List<String> tagsList = userMapper.getTags(uid);
        return tagsList;
    }

    @Override
    public Integer updateTags(Integer uid, String newTags) {
        Integer result = userMapper.updateTags(uid,','+newTags);
        System.out.println(uid);
        System.out.println(newTags);
        return result;
    }

    @Override
    public List<Post> findPost(Integer uid) {
        return userMapper.findPost(uid);
    }

    @Override
    public List<Post> findCollectedPost(Integer uid) {
        return userMapper.findCollectedPost(uid);
    }

    @Override
    public List<Post> findHistory(Integer uid) {
        return userMapper.findHistoryPost(uid);
    }

    @Override
    public boolean deleteHistory(Integer uid) {
        int result = 0;
        int count = userMapper.getHistoryCount(uid);
        if(count>0){
             result = userMapper.deleteHistory(uid);
        }
        if (result>0 || count==0){
            return true;
        }else{
            return false;
        }
    }
    public List<Film> recommendationFilm(Integer uid){
        String user_tag = userMapper.getUserTags(uid);
        String[] user_tags= user_tag.split(",");
        List<String> tagList = Arrays.asList(user_tags);
        List<Film> films=null;
        if (tagList.isEmpty()){
             films = filmMapper.findAllFilms();
        }else{
             films = userMapper.recommendationFilm(tagList);
             if (films.isEmpty()){
                 films = filmMapper.findAllFilms();
             }
        }
        return films;
    }
}
