package com.example.demo.Controller;

import com.example.demo.Service.PostService;
import com.example.demo.pojo.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class PostController {

    @Autowired
    private PostService postService;

    //根据电影fid查询所有帖子 pid （integer）
    @GetMapping("/film_post/{fid}")
    public ResponseEntity<Object> getPostsByFid(@PathVariable Integer fid) {
        System.out.println(fid);
        List<PostShow> film_posts = postService.getPostsByFid(fid);
        if (film_posts != null) {
            // 构建成功时返回的 JSON 数据
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("code", 0);
            responseData.put("data", film_posts);
            return ResponseEntity.ok(responseData);
        } else {
            // 返回 400 Response，空的 JSON 对象
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Collections.emptyMap());
        }
    }

    //查询帖子 pid （integer）
    @GetMapping("/post_detail/{pid}")
    public ResponseEntity<Object> getPostByPid(@PathVariable Integer pid) {
        System.out.println(pid);
        PostShow post = postService.getPostByPid(pid);
        if (post != null) {
            // 构建成功时返回的 JSON 数据
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("code", 0);
            responseData.put("data", post);
            return ResponseEntity.ok(responseData);
        } else {
            // 返回 400 Response，空的 JSON 对象
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Collections.emptyMap());
        }
    }

    //发布帖子
    @PostMapping(path = "/uploadpost",consumes = MediaType.APPLICATION_XML_VALUE)
    public ResponseEntity<Object> createPostFromXml(@RequestBody PostRequest postRequest) {
        Post post = postService.createPost(postRequest);
        if(post!=null){
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("code", 0);
            responseData.put("data",post);
            return ResponseEntity.ok(responseData);
        }
        else{
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("code", 1);
            return ResponseEntity.ok(responseData);
        }
    }

    //添加浏览历史
    @PostMapping("/addHistoryPost")
    public ResponseEntity<?> findPost(@RequestBody Relation relation_history){
        Relation relation = new Relation(relation_history.getUid(),relation_history.getPid(),"h");
        boolean result = postService.addHistoryPost(relation);
        if (result){
            return ResponseEntity.ok().body("{\"code\": 200, \"message\": \"add history successful\"}");
        }else{
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("{\"code\": 500, \"message\": \"add history failed\"}");
        }
    }
    //修改帖子
    @PutMapping("/updatepost")
    public ResponseEntity<Object> updatePost(@RequestBody Post p) {
        boolean result = postService.updatePost(p);
        Post post =  postService.findPostById(p.getPid());
        if(result){
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("code", 0);
            responseData.put("data",post);
            return ResponseEntity.ok(responseData);
        }
        else{
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("code", 1);
            responseData.put("message","修改失败");
            return ResponseEntity.ok(responseData);
        }
    }

    //帖子点赞
    @PostMapping(path = "/postlike")
    public ResponseEntity<Object> addPostlike(@RequestParam Integer uid,@RequestParam Integer pid) {
        Relation relation = new Relation(uid,pid,"l");
        boolean result = postService.addPostlike(relation);
        if(result){
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("code", 0);
            responseData.put("message","点赞成功");
            return ResponseEntity.ok(responseData);
        }
        else{
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("code", 1);
            responseData.put("message","点赞失败");
            return ResponseEntity.ok(responseData);
        }
    }

    //取消点赞
    @DeleteMapping(path = "/cancelpostlike")
    public ResponseEntity<Object> cancelPostlike(@RequestParam Integer uid,@RequestParam Integer pid) {
        Relation relation = new Relation(uid,pid,"l");
        boolean result = postService.cancelPostLike(relation);
        if(result){
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("code", 0);
            responseData.put("message","取消点赞成功");
            return ResponseEntity.ok(responseData);
        }
        else{
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("code", 1);
            responseData.put("message","取消点赞失败");
            return ResponseEntity.ok(responseData);
        }
    }
    //删除帖子
    @DeleteMapping("/post/{pid}")
    public ResponseEntity<Object> deleteComment(@PathVariable("pid") Integer pid) {
        boolean result = postService.deletePostByPid(pid);
        if (result){
            return ResponseEntity.status(HttpStatus.OK).body(Map.of("code", 31));
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("code", 0));
    }
}
