package com.example.demo.Mapper;


import com.example.demo.pojo.Comment;
import com.example.demo.pojo.CommentShow;
import com.example.demo.pojo.Post;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Mapper
public interface CommentMapper {

    List<CommentShow> getCommentsByPid(Integer pid);

    int deleteCommentById(Integer cid);
    int canceldislike(Integer cid);
    int like(Integer cid);

    int dislike(Integer cid);

    int createComment(Comment comment);
    int countComment();
}
