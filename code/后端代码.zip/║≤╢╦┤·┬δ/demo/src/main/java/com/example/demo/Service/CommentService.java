package com.example.demo.Service;

import com.example.demo.pojo.Comment;
import com.example.demo.pojo.CommentShow;

import java.util.List;

public interface CommentService {

    List<CommentShow> getCommentsByPid(Integer pid);
    boolean deleteCommentByCid(Integer cid);

    boolean addCommentlike(Integer cid);
    boolean addCommentdislike(Integer cid);
    boolean createComment(Comment comment);
    int count();
    boolean cancelCommentdislike(Integer cid);
}
