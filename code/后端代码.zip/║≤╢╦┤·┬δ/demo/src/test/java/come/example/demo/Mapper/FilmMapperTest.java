package come.example.demo.Mapper;

import com.example.demo.Mapper.FilmMapper;
import com.example.demo.pojo.Film;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.IOException;
import java.io.Reader;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@SpringBootTest
@AutoConfigureMockMvc
class FilmMapperTest {

    private static SqlSessionFactory sqlSessionFactory;

    @BeforeAll
    public static void setUp() throws IOException {
        // 读取 MyBatis 配置文件
        Reader reader = Resources.getResourceAsReader("mybatis-config.xml");
        // 创建 SqlSessionFactory
        sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
        reader.close();
    }

    @Test
    void testGetFilmByFid() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            FilmMapper filmMapper = session.getMapper(FilmMapper.class);
            Film film = filmMapper.getFilmByFid(1);
            assertNotNull(film);
            assertEquals(1, film.getFid());
        }
    }

    @Test
    void testFindFilmsByName() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            FilmMapper filmMapper = session.getMapper(FilmMapper.class);
            List<Film> films = filmMapper.findFilmsByName("你想活出怎样的人生");
            assertNotNull(films);
            assertFalse(films.isEmpty());
            assertEquals("你想活出怎样的人生", films.get(0).getFname());
        }
    }

    @Test
    void testGetFilmsByTags() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            FilmMapper filmMapper = session.getMapper(FilmMapper.class);
            List<Film> films = filmMapper.getFilmsByTags(List.of("喜剧"));
            assertNotNull(films);
            assertFalse(films.isEmpty());
        }
    }
}
