package come.example.demo.Controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class FilmControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Resource
    private ObjectMapper objectMapper;
    @Test
    void getFilmByFid() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/film/{fid}", 1))
                .andExpect(status().isOk());
    }

    @Test
    void searchFilmByName() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.post("/film/ser/{fname}","你想活出怎样的人生"))
                .andExpect(status().isOk());
    }

    @Test
    void getFilmByTags() throws Exception {
        // 构造电影类型列表
        List<String> movieTypes = Arrays.asList("喜剧", "动漫");

        // 将电影类型列表转换为 JSON 格式
        String jsonContent = objectMapper.writeValueAsString(movieTypes);

        // 发起 POST 请求，查询电影
        mockMvc.perform(MockMvcRequestBuilders.post("/film")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonContent))
                .andExpect(status().isOk());
    }
}
