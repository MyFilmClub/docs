package come.example.demo.Service;

import com.example.demo.Service.PostService;
import com.example.demo.pojo.Post;
import com.example.demo.pojo.PostRequest;
import com.example.demo.pojo.Relation;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import javax.annotation.Resource;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Resource
class PostServiceTest {

    @Resource
    private PostService postService;


    @Test
    void createPost() {
        // 测试创建文章功能
        PostRequest post = new PostRequest();
        post.setUid(1);
        post.setPtitle("测试文章");
        post.setPcontent("这是一篇测试文章内容。");
        post.setLikenum(0);
        post.setCollectnum(0);
        post.setSeenum(0);
        // 假设还设置了其他属性...
        Post result = postService.createPost(post);
        assertTrue(result!=null); // 断言文章创建是否成功
    }

    @Test
    void updatePost() {
        // 测试更新文章功能
        Post post = new Post();
        post.setPid(1);
        post.setPtitle("更新后的文章标题");
        post.setPcontent("更新后的文章内容。");
        // 假设还设置了其他属性...
        boolean result = postService.updatePost(post);
        assertTrue(result); // 断言文章更新是否成功
    }

    @Test
    void addPostlike() {
        // 测试增加文章点赞功能
        Relation relation = new Relation(1,2,"l");
        boolean result = postService.addPostlike(relation);
        assertTrue(result); // 断言点赞是否成功
    }

    @Test
    void addHistoryPost() {
        // 测试添加历史文章功能
        Relation relation = new Relation(1,3,"h");
        boolean result = postService.addHistoryPost(relation);
        assertTrue(result); // 断言添加历史文章是否成功
    }



    @Test
    void deletePostByPid() {
        // 测试删除文章功能
        boolean result = postService.deletePostByPid(2);
        assertTrue(result); // 断言删除是否成功
    }

    @Test
    void cancelPostLike() {
        // 测试取消文章点赞功能
        Relation relation = new Relation(1,2,"l");
        boolean result = postService.cancelPostLike(relation);
        assertTrue(result); // 断言取消点赞是否成功
    }
}
