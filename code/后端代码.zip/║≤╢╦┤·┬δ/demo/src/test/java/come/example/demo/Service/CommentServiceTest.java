package come.example.demo.Service;

import com.example.demo.Service.CommentService;
import com.example.demo.pojo.Comment;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import javax.annotation.Resource;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Resource
public class CommentServiceTest {
    @Resource
    private CommentService commentService;

    @Test
    void deleteCommentByCid() {

        // 测试删除评论功能
        boolean result = commentService.deleteCommentByCid(1);
        assertTrue(result); // 断言删除是否成功
    }

    @Test
    void addCommentlike() {
        // 测试增加评论点赞功能
        boolean result = commentService.addCommentlike(2);
        assertTrue(result); // 断言点赞是否成功
    }

    @Test
    void addCommentdislike() {
        // 测试增加评论点踩功能
        boolean result = commentService.addCommentdislike(2);
        assertTrue(result); // 断言点踩是否成功
    }

    @Test
    void createComment() {
        // 测试创建评论功能
        Comment comment = new Comment();
        Integer new_cid = commentService.count()+1;
        comment.setCid(new_cid);
        comment.setCcontent("Test Comment");
        comment.setLikenum(0);
        comment.setDislikenum(0);
        comment.setUid(1);
        comment.setPid(2);
        boolean result = commentService.createComment(comment);
        assertTrue(result); // 断言评论创建是否成功
    }


    @Test
    void cancelCommentdislike() {
        // 测试取消评论点踩功能
        boolean result = commentService.cancelCommentdislike(2);
        assertTrue(result); // 断言取消点踩是否成功
    }
}
