package come.example.demo.Mapper;

import com.example.demo.Mapper.UserMapper;
import com.example.demo.pojo.Film;
import com.example.demo.pojo.Post;
import com.example.demo.pojo.Relation;
import com.example.demo.pojo.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@AutoConfigureMockMvc

class UserMapperTest {

    private static SqlSessionFactory sqlSessionFactory;

    @BeforeAll
    static void setUp() throws IOException {
        // 读取 MyBatis 配置文件
        Reader reader = Resources.getResourceAsReader("mybatis-config.xml");
        // 创建 SqlSessionFactory
        sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
        reader.close();
    }

    @Test
    void testFindByUsernameAndPassword() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            UserMapper userMapper = session.getMapper(UserMapper.class);
            User user = userMapper.findByUsernameAndPassword("Lily", "1234");

            assertNotNull(user); // 确保用户不为空
            // 根据实际情况验证用户对象的其他属性
        }
    }

    @Test
    void testInsertUser() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            UserMapper userMapper = session.getMapper(UserMapper.class);
            User user = new User();
            user.setUid(userMapper.getMaxUid()+1);
            user.setUsername("Tom");
            user.setPassword("123456");
            // 设置其他属性...

            int result = userMapper.insertUser(user);

            assertNotNull(user.getUid()); // 确保插入后用户ID被赋值
            assertEquals(1, result); // 验证插入操作影响的行数
        }
    }
    @Test
    void testUpdateUserInfo() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            UserMapper userMapper = session.getMapper(UserMapper.class);
            User updateUser = new User();
            updateUser.setUid(1);
            updateUser.setUsername("updatedusername");
            // 设置其他属性...

            int result = userMapper.updateUserInfo(updateUser);

            assertEquals(1, result); // 验证更新操作影响的行数
        }
    }

    @Test
    void testAddRelation() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            UserMapper userMapper = session.getMapper(UserMapper.class);
            Relation relation = new Relation();
            relation.setUid(1);
            relation.setPid(1);
            relation.setRelation("c");
            // 设置其他属性...

            int result = userMapper.addRelation(relation);

            assertEquals(1, result); // 验证添加关系操作影响的行数
        }
    }

    @Test
    void testFindUserByName() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            UserMapper userMapper = session.getMapper(UserMapper.class);
            int result = userMapper.findUserByName("Lily");

            // 验证根据用户名查找用户操作影响的行数
            assertEquals(result,1);
        }
    }


    @Test
    void testRecommendationFilm() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            UserMapper userMapper = session.getMapper(UserMapper.class);
            List<String> tagList = new ArrayList<>();

            // 添加其他标签...
            List<Film> recommendedFilms = userMapper.recommendationFilm(tagList);

            // 根据实际情况验证返回的推荐电影列表是否符合预期
            assert(!recommendedFilms.isEmpty());
        }
    }

    @Test
    void testAddCollectNum() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            UserMapper userMapper = session.getMapper(UserMapper.class);
            int result = userMapper.addCollectNum(1);
            // 验证增加收藏数量操作影响的行数
            assertEquals(result,1);
        }
    }



}
