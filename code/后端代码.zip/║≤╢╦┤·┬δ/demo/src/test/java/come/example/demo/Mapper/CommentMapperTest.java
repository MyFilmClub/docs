package come.example.demo.Mapper;

import com.example.demo.Mapper.CommentMapper;
import com.example.demo.pojo.Comment;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.IOException;
import java.io.Reader;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@AutoConfigureMockMvc
class CommentMapperTest {

    private static SqlSessionFactory sqlSessionFactory;

    @BeforeAll
    public static void setUp() throws IOException {
        // 读取 MyBatis 配置文件
        Reader reader = Resources.getResourceAsReader("mybatis-config.xml");
        // 创建 SqlSessionFactory
        sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
        reader.close();
    }
    @Test
    void deleteCommentById() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            CommentMapper commentMapper = session.getMapper(CommentMapper.class);
            int result = commentMapper.deleteCommentById(1);
            //验证应该删除一条记录
            assertEquals(1,result);
        }
    }

    @Test
    void canceldislike() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            CommentMapper commentMapper = session.getMapper(CommentMapper.class);
            int result = commentMapper.canceldislike(1);
            //验证应该有一条记录修改
            assertEquals(1, result);
        }
    }

    @Test
    void like() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            CommentMapper commentMapper = session.getMapper(CommentMapper.class);
            int result = commentMapper.like(1);
            //应该有一条记录改变
            assertEquals(1, result);
        }
    }

    @Test
    void dislike() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            CommentMapper commentMapper = session.getMapper(CommentMapper.class);
            int result = commentMapper.dislike(1);
            //应该有一条记录改变
            assertEquals(1, result);
        }
    }

    @Test
    void createComment() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            CommentMapper commentMapper = session.getMapper(CommentMapper.class);
            int commentCountBeforeCreation = commentMapper.countComment();
            // 模拟创建一个新的评论
            Comment newComment = new Comment(commentCountBeforeCreation+1,"for test",0,0,1,1);
            int result = commentMapper.createComment(newComment);

            // 验证返回的结果是否是一个有效的评论 ID（大于0的整数）
            assertTrue(result > 0, "Comment creation should return a valid ID");

            // 验证创建评论后，通过查询数据库或者其他方法来确认评论已经成功创建
            // 验证创建评论后，再次调用获取评论数量的方法，确认评论数量是否增加了
            int commentCountAfterCreation = commentMapper.countComment();
            assertEquals(commentCountBeforeCreation + 1, commentCountAfterCreation, "Comment count should increase after creating a new comment");
        }
    }
}
