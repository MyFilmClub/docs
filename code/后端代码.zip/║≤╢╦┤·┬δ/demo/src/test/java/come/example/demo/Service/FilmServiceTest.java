package come.example.demo.Service;

import com.example.demo.Service.FilmService;
import com.example.demo.pojo.Film;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import javax.annotation.Resource;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Resource
class FilmServiceTest {

    @Resource
    private FilmService filmService;

    @Test
    void getFilmByFid() {
        // 测试根据电影ID获取电影信息功能
        Film film = filmService.getFilmByFid(1);
        assertNotNull(film); // 断言电影对象不为空
        // 可以根据实际情况进行进一步的断言验证
    }

    @Test
    void getFilmsByName() {
        // 测试根据电影名称获取电影列表功能
        String filmName = "你想活出怎样的人生";
        // 假设数据库中有符合条件的电影数据
        assertNotNull(filmService.getFilmsByName(filmName)); // 断言获取的电影列表不为空
    }

    @Test
    void getFilmByTags() {
        // 测试根据标签获取电影列表功能
        String tag = "喜剧";
        List<String> tags = Arrays.asList(tag);
        // 假设数据库中有符合条件的电影数据
        assertNotNull(filmService.getFilmByTags(tags)); // 断言获取的电影列表不为空
    }
}
