package come.example.demo.Controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class CommentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    void deleteComment() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.delete("/comment/{cid}", 1))
                .andExpect(status().isOk());
    }

    @Test
    void addCommentlike() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.post("/commentlike/{cid}", 1))
                .andExpect(status().isOk());
    }

    @Test
    void addCommentdislike() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.post("/dislike/{cid}", 1))
                .andExpect(status().isOk());
    }

    @Test
    void cancelCommentdislike() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.post("/canceldislike/{cid}", 1))
                .andExpect(status().isOk());
    }

    @Test
    void createPostFromXml() throws Exception {
        String xmlContent = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>"+
                "<data>\n"+
                "<ccontent>string</ccontent>\n" +
                "  <likenum>0</likenum>\n" +
                "  <dislikenum>0</dislikenum>\n" +
                "  <uid>1</uid>\n" +
                "  <pid>2</pid>" +
                "</data>\n";
        mockMvc.perform(MockMvcRequestBuilders.post("/comment")
                        .contentType(MediaType.APPLICATION_XML)
                        .content(xmlContent))
                .andExpect(status().isOk());
    }
}
