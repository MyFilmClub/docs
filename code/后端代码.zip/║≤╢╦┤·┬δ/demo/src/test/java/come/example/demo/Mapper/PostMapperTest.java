package come.example.demo.Mapper;

import com.example.demo.Mapper.PostMapper;
import com.example.demo.pojo.Post;
import com.example.demo.pojo.Relation;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.IOException;
import java.io.Reader;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
@AutoConfigureMockMvc
class PostMapperTest {

    private static SqlSessionFactory sqlSessionFactory;

    @BeforeAll
    static void setUp() throws IOException {
        // 读取 MyBatis 配置文件
        Reader reader = Resources.getResourceAsReader("mybatis-config.xml");
        // 创建 SqlSessionFactory
        sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
        reader.close();
    }

    @Test
    void testInsertPost() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            PostMapper postMapper = session.getMapper(PostMapper.class);
            Post post = new Post();
            post.setPid(postMapper.getArticlePageCount()+1);
            post.setUid(2);
            post.setPtitle("Test Post");
            post.setPcontent("test new a post");
            post.setSeenum(0);
            post.setCollectnum(0);
            post.setLikenum(0);
            // 设置其他属性...

            int result = postMapper.insertPost(post);

            assertNotNull(post.getPid()); // 确保插入后主键被赋值
            assertEquals(1, result); // 验证插入操作影响的行数
        }
    }

    @Test
    void testUpdatePost() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            PostMapper postMapper = session.getMapper(PostMapper.class);
            Post post = new Post();
            post.setPid(1);
            post.setPcontent("a");
            post.setPtitle("Updated Test Post");
            // 设置其他需要更新的属性...
            int result = postMapper.updatePost(post);

            assertEquals(1, result); // 验证更新操作影响的行数
        }
    }

    @Test
    void testCollect() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            PostMapper postMapper = session.getMapper(PostMapper.class);
            int result = postMapper.collect(1);
            assertEquals(1, result); // 验证收藏操作影响的行数
        }
    }

    @Test
    void testLike() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            PostMapper postMapper = session.getMapper(PostMapper.class);
            int result = postMapper.like(1);
            assertEquals(1, result); // 验证点赞操作影响的行数
        }
    }

    @Test
    void testAddHistoryPost() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            PostMapper postMapper = session.getMapper(PostMapper.class);
            Relation relation = new Relation();
            relation.setUid(1);
            relation.setPid(1);
            relation.setRelation("h");

            int result = postMapper.addHistoryPost(relation);

            assertEquals(1, result); // 验证添加历史记录操作影响的行数
        }
    }

    @Test
    void testFindPostById() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            PostMapper postMapper = session.getMapper(PostMapper.class);
            Post post = postMapper.findPostById(1);

            assertNotNull(post); // 确保返回的文章不为空
            // 根据实际情况验证返回的文章对象的其他属性
        }
    }
    @Test
    void testAddLikePost() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            PostMapper postMapper = session.getMapper(PostMapper.class);
            Relation relation = new Relation();
            relation.setUid(1);
            relation.setPid(2);
            relation.setRelation("l");
            int result = postMapper.addLikePost(relation);

            // 验证添加喜欢关系操作影响的行数
            assert(result>0);
        }
    }
    @Test
    void testDeleteLikeRelation() {
        try (SqlSession session = sqlSessionFactory.openSession()) {
            PostMapper postMapper = session.getMapper(PostMapper.class);
            Relation relation = new Relation();
            relation.setUid(1);
            relation.setPid(2);
            relation.setRelation("l");
            int result = postMapper.deleteLikeRelation(relation);

            // 验证删除喜欢关系操作影响的行数
            assert(result>=1);
        }
    }

}
