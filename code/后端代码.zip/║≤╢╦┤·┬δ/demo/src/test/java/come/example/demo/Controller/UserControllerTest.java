package come.example.demo.Controller;

import com.example.demo.pojo.Collect;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class UserControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    void loginUser() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.post("/user/login")
                        .param("username", "Lily")
                        .param("password", "1234"))
                .andExpect(status().isOk());
    }

    @Test
    void signUpUser() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.post("/user/signup")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\": \"Alice\", \"password\": \"1234\"}"))
                .andExpect(status().isOk());
    }

    @Test
    void updateUserInfo() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.put("/user")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"uid\": \"1\", \"username\": \"Anna\"}"))
                .andExpect(status().isOk());
    }

    @Test
    void collectPost() throws Exception {
        // 创建 Collect 对象作为请求体内容
        Collect collect = new Collect();
        collect.setUid(1);
        collect.setPid(3);

        // 使用 ObjectMapper 将对象转换为 JSON 字符串
        ObjectMapper objectMapper = new ObjectMapper();
        String requestBody = objectMapper.writeValueAsString(collect);

        // 发起 POST 请求，收藏帖子
        mockMvc.perform(MockMvcRequestBuilders.post("/collect")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestBody))
                .andExpect(status().isOk());
    }
    @Test
    void findPost() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/findPost/{uid}" ,"1"))
                .andExpect(status().isOk());
    }

    @Test
    void findCollectedPost() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/findCollectedPost/{uid}",1))
                .andExpect(status().isOk());
    }

    @Test
    void findHistory() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/findHistory/{uid}","1"))
                .andExpect(status().isOk());
    }

    @Test
    void deleteHistory() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/deleteHistory/{uid}","1"))
                .andExpect(status().isOk());
    }

    @Test
    void recommendFilm() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/recommendation/{uid}","1"))
                .andExpect(status().isOk());
    }
}
