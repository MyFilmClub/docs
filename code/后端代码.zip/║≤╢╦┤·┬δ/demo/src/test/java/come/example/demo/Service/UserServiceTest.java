package come.example.demo.Service;

import com.example.demo.Service.UserService;
import com.example.demo.pojo.Relation;
import com.example.demo.pojo.User;
import com.example.demo.pojo.UserRequest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import javax.annotation.Resource;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Resource
class UserServiceTest {

    @Resource
    private UserService userService;

    @Test
    void login() {
        // 测试用户登录功能
        String username = "test_user";
        String password = "test_password";
        User user = userService.login(username, password);
        assertNotNull(user); // 断言登录后返回的用户对象不为空
        // 可以根据实际情况进行进一步的断言验证
    }

    @Test
    void registerUser() {
        // 测试用户注册功能
        UserRequest user = new UserRequest();
        user.setUsername("new_user");
        user.setPassword("542");
        // 假设还设置了其他属性...
        boolean result = userService.registerUser(user);
        assertTrue(result); // 断言注册是否成功
    }

    @Test
    void updateUser() {
        // 测试更新用户信息功能
        User user = new User();
        user.setUid(1);
        user.setUsername("updated_user");
        user.setPassword("4432");
        // 假设还设置了其他属性...
        boolean result = userService.updateUser(user);
        assertTrue(result); // 断言更新用户信息是否成功
    }

    @Test
    void collectPost() {
        // 测试用户收藏文章功能
        Relation relation = new Relation(1,3,"c");
        boolean result = userService.collectPost(relation);
        assertTrue(result); // 断言收藏文章是否成功
    }

    @Test
    void findPost() {
        // 测试查找用户发布的文章功能
        int userId = 1;
        assertNotNull(userService.findPost(userId)); // 断言返回的文章列表不为空
        // 可以根据实际情况进行进一步的断言验证
    }

    @Test
    void findCollectedPost() {
        // 测试查找用户收藏的文章功能
        int userId = 1;
        assertNotNull(userService.findCollectedPost(userId)); // 断言返回的文章列表不为空
        // 可以根据实际情况进行进一步的断言验证
    }

    @Test
    void deleteHistory() {
        // 测试删除用户浏览历史功能
        boolean result = userService.deleteHistory(1); // 假设删除历史记录
        assertTrue(result); // 断言删除历史记录是否成功
    }

    @Test
    void recommendationFilm() {
        // 测试为用户推荐电影功能
        int userId = 1;
        assertNotNull(userService.recommendationFilm(userId)); // 断言返回的电影列表不为空
        // 可以根据实际情况进行进一步的断言验证
    }
}
