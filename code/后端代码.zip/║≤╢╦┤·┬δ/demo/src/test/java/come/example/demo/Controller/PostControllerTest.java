package come.example.demo.Controller;

import com.example.demo.pojo.Post;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class PostControllerTest {

    @Autowired
    private MockMvc mockMvc;


    @Test
    void createPostFromXml() throws Exception {
        // 构造 XML 格式的文章数据
        String xmlContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+"<data>\n<post>\n" +
                "  <title>测试文章</title>\n" +
                "  <content>这是一篇测试文章内容。</content>\n" +
                "</post>\n</data>";

        // 发起 POST 请求，创建文章
        mockMvc.perform(MockMvcRequestBuilders.post("/post")
                        .contentType(MediaType.APPLICATION_XML)
                        .content(xmlContent))
                .andExpect(status().isOk());
    }


//    @Test
//    void updatePost() throws Exception {
//        // 构造 JSON 格式的文章数据
//        Post post = new Post();
//        post.setPid(2);
//        post.setTitle("更新后的文章标题");
//        post.setPcontent("更新后的文章内容。");
//        String jsonContent = new JSONObject(post.getPcontent()).toString();
//
//        // 发起 PUT 请求，更新文章
//        mockMvc.perform(MockMvcRequestBuilders.put("/post/{pid}", 1)
//                        .contentType(MediaType.APPLICATION_JSON)
//                        .content(jsonContent))
//                .andExpect(status().isOk());
//    }

    @Test
    void addPostlike() throws Exception {
        // 发起 POST 请求，给文章点赞
        mockMvc.perform(MockMvcRequestBuilders.post("/postlike")
                        .param("uid","1")
                        .param("pid","2")
                )
                .andExpect(status().isOk());
    }

    @Test
    void cancelPostlike() throws Exception {
        // 发起 POST 请求，取消文章点赞
        mockMvc.perform(MockMvcRequestBuilders.delete("/cancelpostlike")
                        .param("uid","1")
                        .param("pid","3"))
                .andExpect(status().isOk());
    }

    @Test
    void deleteComment() throws Exception {
        // 发起 DELETE 请求，删除评论
        mockMvc.perform(MockMvcRequestBuilders.delete("/post/{pid}", 2))
                .andExpect(status().isOk());
    }
}
